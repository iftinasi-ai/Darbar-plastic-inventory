# IFNAS DARBAR PLASTIC Inventory APK

## Features
- Initial stock list transcribed from the supplied handwritten note. Entries marked X start at zero.
- Add, edit, delete, search, Stock In, Stock Out.
- Offline stock storage on this device using WebView localStorage.
- PDF report using Android Print / Save as PDF.

## Build APK on GitHub
1. Create a new GitHub repository named `ifnas-darbar-plastic`.
2. Upload all files and folders from this project ZIP to the repository root.
3. Open **Actions** and allow workflows if GitHub asks.
4. Select **Build IFNAS DARBAR PLASTIC APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `IFNAS-DARBAR-PLASTIC-APK`.
6. Extract the ZIP and install `app-debug.apk` on your Android phone.

The first build may take several minutes. This is a debug APK for personal use, not a Play Store release.
